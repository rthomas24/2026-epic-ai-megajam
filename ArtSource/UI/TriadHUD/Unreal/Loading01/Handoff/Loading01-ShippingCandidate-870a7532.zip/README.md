# Loading01 private Shipping candidate — remote cook handoff

Nick requests actual packaged Shipping verification of New Game, Continue, and return-to-menu. Production defaults must remain unchanged until his visual approval.

Exact base: 870a753255bc75b4ac9fe84a4f77e5b488815f1e.
UI source checkpoint: 228fdc420e00a9293642ef0a0bbf4d9b9420499f.
Engine: Unreal Engine 5.9 MegaJam Preview, CL 60351404.

The candidate payload contains exactly three new HUD plugin source/test files and one private Presentation/DA_UI_Style.uasset override. It contains no development-only module fixture. Validate every payload byte hash against candidate-manifest.json before building. Preserve the original Gameplay/Characters/FX/DA_UI_Style.uasset at SHA256 4c98183f9108ec68beb1863a03552eb8b9a0e7f74b3c5c2a8cc106f4a2e73267.

The private style duplicates the exact existing fallback and changes only LoadingWidgetClass to /Script/TriadDriftHUD.TDLoadingWidget. All 33 fields were compared, including a fresh matching Editor process; reports are included. No map, Config, gameplay Source or production style was edited. This override is for this isolated review package only, not Main integration.

In a Lead-approved isolated checkout of the exact base, hydrate Content and Plugins, apply the four payload paths, then build the Editor and Shipping targets and cook/package the normal configured maps. The local Editor build and Shipping compile/link both passed. Both local cook attempts stopped at the 1.5 GiB/10-second memory guard; they are not successful Shipping packages. Current local headroom is below the 5.5 GiB trial requirement.

Use bounded, memory-monitored builds. Reuse matching build products only. Validated optional lower-memory cook controls include -CookProcessCount=1 -Partialgc -asyncassetcompilationmaxconcurrency=1 -asyncstaticmeshcompilation=0 -asyncstaticmeshcompilationmaxconcurrency=1 -asynctexturecompilation=0 -asynctexturecompilationmaxconcurrency=1 and commandline-only Editor CookSettings MemoryMinFreePhysical=4096, PackagesPerGC=10, MaxNumPackagesBeforePartialGC=10, MaxPrecacheShaderJobs=1, MaxConcurrentShaderJobs=1; Shader NumUnusedShaderCompilingThreads=15. Preserve ordinary game transition timing and all production configuration.

Return the packaged Win64 Shipping archive, SHA256, exact base/overlay manifest, build/cook logs and executable identity to Lead. UI will launch it on its default boot map with a fresh private UserDir and ordinary menu input, capture New Game / Continue / return-to-menu and confirm the loading widget clears. No cheats, console, MCP injection, map override or development review fixture counts as Shipping acceptance.

State: compiled and private style verified; cook, Shipping route checks and actual Shipping screenshots remain pending. Prior Editor-game screenshots must not be presented as Shipping evidence.
